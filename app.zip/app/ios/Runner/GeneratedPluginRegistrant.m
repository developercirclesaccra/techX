//
//  Generated file. Do not edit.
//

#import "GeneratedPluginRegistrant.h"
#import <pdftron_flutter/PdftronFlutterPlugin.h>
#import <permission_handler/PermissionHandlerPlugin.h>

@implementation GeneratedPluginRegistrant

+ (void)registerWithRegistry:(NSObject<FlutterPluginRegistry>*)registry {
  [PdftronFlutterPlugin registerWithRegistrar:[registry registrarForPlugin:@"PdftronFlutterPlugin"]];
  [PermissionHandlerPlugin registerWithRegistrar:[registry registrarForPlugin:@"PermissionHandlerPlugin"]];
}

@end
