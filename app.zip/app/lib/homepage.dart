import 'package:flutter/material.dart';

class Homepage extends StatefulWidget {
  @override
  _HomepageState createState() => _HomepageState();
}

class _HomepageState extends State<Homepage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Home',
          style: TextStyle(
            fontSize: 22,
            fontFamily: 'Montserrat',
          ),
        ),
      ),
      body: Container(
        child: Column(
          children: <Widget>[
            Flexible(
              child: Center(
                child: Image.asset(
                  'images/boy.png',
                  height: 80,
                ),
              ),
            ),
            Flexible(
              child: Column(
                children: <Widget>[
                  Text(
                    'Hello ,',
                    style: TextStyle(
                      fontFamily: 'Montserrat',
                      fontSize: 40,
                      fontWeight: FontWeight.w700,
                      color: Color(0xFF1A2A4F),
                    ),
                  ),
                  Text(
                    'Nunya',
                    style: TextStyle(
                      fontFamily: 'Montserrat',
                      fontSize: 45,
                      fontWeight: FontWeight.w900,
                      color: Color(0xFF1A2A4F),
                    ),
                  ),
                ],
              ),
            ),
            Column(
              children: <Widget>[
                Column(
                  children: <Widget>[
                    Container(
                      height: 40,
                      width: 40,
                      color: Color(0xFF1A2A4F),
                    ),
                    Container(
                      height: 30,
                      width: 400,
                      color: Color(0xFF1A2A4F),
                    ),
                  ],
                )
              ],
            ),
          ],
        ),
      ),
    );
  }
}
